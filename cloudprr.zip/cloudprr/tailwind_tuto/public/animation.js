
let toggle = document.querySelector("#profileToggler");
let content = document.querySelector("#profileDropdown");
toggle.addEventListener("click", () => {
    console.log("hello");
    content.classList.toggle("hidden");
});
