const burger = document.querySelector('#burger');
const EX = document.querySelector('#EX');
const menu  = document.querySelector('#menu');

burger.addEventListener('click', () => {
    if (menu.classList.contains('hidden')){
        menu.classList.remove('hidden');
    } 
})
EX.addEventListener('click', () => {
        menu.classList.add('hidden');
})