function sendbtn() {

	var printtext = document.getElementById('chatmsg');
	var copytext = document.getElementById('typemsg');
	

	var copiedtext = copytext.value;
	
	
	var printnow = '<li class="flex justify-end pt-2"> <div class="relative max-w-xl px-4 py-2 text-gray-700 bg-gray-100 rounded shadow">'+copiedtext+' </span> </div> </li>';
	document.getElementById("typemsg").value ="";

	
	printtext.insertAdjacentHTML('beforeend', printnow);

	var box = document.getElementById('journal-scroll');
	box.scrollTop = box.scrollHeight;
	
}